import matplotlib.pyplot as plt


def func(x):
    return 9640 / x + 180 * (x+1)


t = list(range(1, 51))
y = [func(i) for i in t]

y_min = min(y)
t_min = y.index(y_min) + 1

plt.plot(t, y, color='black')
plt.plot(t_min, y_min, linewidth='50', marker='.', color='red')
plt.annotate("Smallest point  (" + str(t_min) + " , " + str(y_min) + ")",xy=(t_min+1, y_min+1),xytext=(t_min+5, y_min+5),color="blue",weight="bold",
arrowprops=dict(headlength=5, connectionstyle="arc3",color="blue"))
plt.xlabel("t")
plt.ylabel(r"$E_{a}(t)$")
plt.show()