x = [2 3 4 5 7 9 12 14 17 21 28 56];
y = [35 42 47 53 59 65 68 73 76 82 86 99]';
X = log(x);
x1 = [ones(12,1) X']
[b,bint,r,rint,status]=regress(y,x1);
b