%�ع����
x=20:5:65;
y=[13.2 15.1 16.4 17.1 17.9 18.7 19.6 21.2 22.5 24.3];
X=[ones(length(x),1),x'];
[b,bint,r,rint,stats]=regress(y',X)
sigga2=sum(r.^2)/(length(x)-2);

%Sx2=var(x);
Lxx=var(x)*(length(x)-1);
z=b(1)+b(2)*x;
Y = b(1)+b(2)*42
x_bar=mean(x);
u=sigga2*2.306*sqrt(1+0.1+(42-x_bar)^2/Lxx);
a=Y-u;
b=Y+u;
[a,b]
figure(1),hold on;
plot(x,y,'k+',x,z,'r','LineWidth',2,'LineWidth',2);
legend('ԭʼ����','�ع鷽��','Location','southeast');
grid on;
figure(2),rcoplot(r,rint);
%set(gca,'Color','w');

