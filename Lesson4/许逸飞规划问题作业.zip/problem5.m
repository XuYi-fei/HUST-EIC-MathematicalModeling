clear;
clc;
fprintf("\n***********************水库运水问题1***************************\n");
c = [160; 130; 220; 170; 140; 130; 190; 150; 190; 200; 230];
intcon = [1,2,3,4,5,6,7,8,9,10,11];
A = [1,0,0,0,1,0,0,0,1,0,0; 0,1,0,0,0,1,0,0,0,1,0; 0,0,1,0,0,0,1,0,0,0,1;
    0,0,0,1,0,0,0,1,0,0,0; -1,0,0,0,-1,0,0,0,-1,0,0; 0,-1,0,0,0,-1,0,0,0,-1,0; 
    0,0,-1,0,0,0,-1,0,0,0,-1; 0,0,0,-1,0,0,0,-1,0,0,0];
b = [80;140;30;50;-30;-70;-10;-10];
Aeq = [1,1,1,1,0,0,0,0,0,0,0; 0,0,0,0,1,1,1,1,0,0,0; 0,0,0,0,0,0,0,0,1,1,1];
beq = [50; 60; 50];
lb = zeros(11,1);
ub = [inf; inf; inf; inf; inf; inf; inf; inf; inf; inf; inf];
[x0, fval0] = linearProg(c, intcon, A, b, Aeq, beq, lb, ub);
result = num2str(x0');
fprintf("This is the first problem: x1=[A to 甲， A to 乙， A to 丙， A to 丁, B to 甲， B to 乙， B to 丙， B to 丁， C to 甲， C to 乙， C to 丙]\n");
fprintf("The variables are: %s\n", result);
fprintf("The final profit is: %.5f\n", 144000-72000-fval0);

fprintf("\n\n\n");

fprintf("\n***********************水库运水问题2***************************\n");
c1 = [-290; -320; -230; -280; -310; -320; -260; -300; -260; -250; -220];
intcon1 = [1,2,3,4,5,6,7,8,9,10,11];
A1 = [1,0,0,0,1,0,0,0,1,0,0; 0,1,0,0,0,1,0,0,0,1,0; 0,0,1,0,0,0,1,0,0,0,1;
    0,0,0,1,0,0,0,1,0,0,0; -1,0,0,0,-1,0,0,0,-1,0,0; 0,-1,0,0,0,-1,0,0,0,-1,0; 
    0,0,-1,0,0,0,-1,0,0,0,-1; 0,0,0,-1,0,0,0,-1,0,0,0; 1,1,1,1,0,0,0,0,0,0,0;
    0,0,0,0,1,1,1,1,0,0,0; 0,0,0,0,0,0,0,0,1,1,1];
b1 = [80;140;30;50;-30;-70;-10;-10; 100; 120;100];
Aeq1 = [];
beq1 = [];
lb1 = zeros(11,1);
ub1 = [inf; inf; inf; inf; inf; inf; inf; inf; inf; inf; inf];
[x1, fval1] = linearProg(c1, intcon1, A1, b1, Aeq1, beq1, lb1, ub1);
result = num2str(x1');
fval1 = -fval1;
fprintf("This is the first problem Version2: x1=[A to 甲， A to 乙， A to 丙， A to 丁, B to 甲， B to 乙， B to 丙， B to 丁， C to 甲， C to 乙， C to 丙]\n");
fprintf("The variables are: %s\n", result);
fprintf("The final profit is: %.5f\n", fval1);

fprintf("\n***********************原油问题***************************\n");
c2 = [-4.8; -5.6; -4.8; -5.6; 10; 8; 6; 0; 0; 0];
intcon2 = [8,9,10];
A2 = [1,1,0,0,-1,-1,-1,0,0,0; 0,0,1,1,0,0,0,0,0,0; -0.5,0,0.5,0,0,0,0,0,0,0;
    0, -0.4, 0, 0.6, 0, 0, 0, 0, 0, 0; 0,0,0,0,1,0,0,-500,0,0; 0,0,0,0,0,1,0,0,-500,0;
    0,0,0,0,0,0,1,0,0,-500; 0,0,0,0,-1,0,0,0,500,0; 0,0,0,0,0,-1,0,0,0,500];
b2 = [500; 1000; 0; 0; 0; 0; 0; 0; 0];
Aeq2 = [];
beq2 = [];
lb2 = zeros(10,1);
ub2 = [inf; inf; inf; inf; 500; 500; 500; 1; 1; 1];
[x2, fval2] = linearProg(c2, intcon2, A2, b2, Aeq2, beq2, lb2, ub2);
fval2 = -fval2;
fprintf("This is the second problem: x1=[A to 甲， A to 乙， A to 丙， A to 丁, B to 甲， B to 乙， B to 丙， B to 丁， C to 甲， C to 乙， C to 丙]\n");
fprintf("The variables are: %s\n");
x2
fprintf("The final profit is: %.5f\n", fval2);


fprintf("\n***********************易拉罐问题***************************\n");
c3 = [-0.1; 0.2226; 0.1833; 0.2618; 0.1695; 0.1571; 0.0196];
intcon3 = [];
A3 = [0, 1.5, 2, 1, 3, 0, 0; 0, 1, 1, 1, 0, 0, 0; 0, 0, 0, 0, 1, 0, 0; 1, -1, -2, 0, -4, 0, 0;
    1, -5, -2, -8, -2.5, 0, 0];
b3 = [144000; 50000; 20000; 0; 0];
Aeq3 = [1, -1, -2, 0, -4, 1, 0; 2, -10, -4, -16, -5, 1, 0];
beq3 = [0; 0];
lb3 = zeros(7,1);
ub3 = [inf; inf; inf; inf; inf; inf; inf; inf; inf; inf; inf];
[x3, fval3] = linearProg(c3, intcon3, A3, b3, Aeq3, beq3, lb3, ub3);
fval3 = -fval3;
% result = num2str(x3);
fprintf("This is the third problem: x1=[模式1， 模式2， 模式3， 模式4， 模式5， 模式6， 模式7]\n");
fprintf("The variables are:");
x3
fprintf("The final profit is: %.5f\n", fval3);


