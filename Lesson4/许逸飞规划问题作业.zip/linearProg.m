function [x,fval] = linearProg(c,intcon, A, b, Aeq, beq, lb, ub)
%LINEARPROG 此处显示有关此函数的摘要
%   此处显示详细说明
[x, fval, exitflag, output] = intlinprog(c, intcon, A, b, Aeq, beq, lb, ub);
end

